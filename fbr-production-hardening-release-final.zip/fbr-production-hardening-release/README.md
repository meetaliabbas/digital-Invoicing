# FBR Digital Invoicing hardening bundle

This release contains:
- `web-app/`: Next.js App Router + Supabase authentication and invoice API foundation.
- `erpnext-fbr-integration/`: uploaded Frappe/ERPNext integration source, preserved as a separate application.
- `supabase/schema.sql`: tenant-scoped database policies and append-only audit events.
- `PRODUCTION_READINESS_REVIEW.md`: scope, static checks, known gaps and deployment blockers.

These components are not a single deployable process. The Frappe app runs inside an ERPNext bench; the web app deploys to Vercel. No live FBR submission is enabled or claimed.


## Current repository compatibility patch

The folder `src/pages/PlatformRedesign/TenantContext.jsx` is a patch for the existing legacy React repository's latest observed Vercel build error. See `APPLY_TO_GITHUB.md` for the copy/commit steps and for the separate `web-app/` Next.js Vercel root. The two apps are distinct: the compatibility patch does not migrate the old React UI into Next.js.

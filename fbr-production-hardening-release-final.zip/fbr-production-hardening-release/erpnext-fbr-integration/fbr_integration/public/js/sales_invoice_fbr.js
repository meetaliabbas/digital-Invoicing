function esc(s) {
    return frappe.utils.escape_html((s || "").toString());
}

// Cache FBR Invoice Settings for the desk session (refresh hits this often).
let __fbr_invoice_settings = null;
let __fbr_invoice_settings_promise = null;

function get_fbr_invoice_settings(force) {
    if (!force && __fbr_invoice_settings) {
        return Promise.resolve(__fbr_invoice_settings);
    }
    if (!force && __fbr_invoice_settings_promise) {
        return __fbr_invoice_settings_promise;
    }
    // Wrap frappe.call — its thenable may lack Promise.finally on desk.
    __fbr_invoice_settings_promise = Promise.resolve(
        frappe.call({
            method: "frappe.client.get_value",
            args: {
                doctype: "FBR Invoice Settings",
                fieldname: ["integration_type", "enabled"],
            },
        })
    )
        .then((r) => {
            __fbr_invoice_settings = (r && r.message) || {};
            return __fbr_invoice_settings;
        })
        .finally(() => {
            __fbr_invoice_settings_promise = null;
        });
    return __fbr_invoice_settings_promise;
}

/** Historic typo fieldname; prefer correct spelling if present on the form. */
function scenario_detail_html_field(frm_or_dict) {
    const fields = frm_or_dict && frm_or_dict.fields_dict
        ? frm_or_dict.fields_dict
        : frm_or_dict || {};
    if (fields.custom_scenario_detail_fields) {
        return "custom_scenario_detail_fields";
    }
    return "custom_scenario_detial_fields";
}

function json_to_html(obj, indent) {
    indent = indent || 0;
    const pad = "  ".repeat(indent);
    const pad1 = "  ".repeat(indent + 1);
    if (obj === null)
        return `<span style="color:#f87171;font-weight:600;">null</span>`;
    if (typeof obj === "boolean")
        return `<span style="color:#c084fc;font-weight:600;">${obj}</span>`;
    if (typeof obj === "number")
        return `<span style="color:#fb923c;font-weight:600;">${obj}</span>`;
    if (typeof obj === "string")
        return `<span style="color:#4ade80;">"${frappe.utils.escape_html(
            obj
        )}"</span>`;
    if (Array.isArray(obj)) {
        if (obj.length === 0) return `<span style="color:#94a3b8;">[]</span>`;
        const items = obj
            .map(
                (v, i) =>
                    `${pad1}${json_to_html(v, indent + 1)}${
                        i < obj.length - 1
                            ? '<span style="color:#94a3b8;">,</span>'
                            : ""
                    }`
            )
            .join("\n");
        return `<span style="color:#94a3b8;">[</span>\n${items}\n${pad}<span style="color:#94a3b8;">]</span>`;
    }
    if (typeof obj === "object") {
        const keys = Object.keys(obj);
        if (keys.length === 0) return `<span style="color:#94a3b8;">{}</span>`;
        const rows = keys
            .map(
                (k, i) =>
                    `${pad1}<span style="color:#7dd3fc;font-weight:600;">"${frappe.utils.escape_html(
                        k
                    )}"</span><span style="color:#94a3b8;">: </span>${json_to_html(
                        obj[k],
                        indent + 1
                    )}${
                        i < keys.length - 1
                            ? '<span style="color:#94a3b8;">,</span>'
                            : ""
                    }`
            )
            .join("\n");
        return `<span style="color:#94a3b8;">{</span>\n${rows}\n${pad}<span style="color:#94a3b8;">}</span>`;
    }
    return frappe.utils.escape_html(String(obj));
}

function show_scenario_details(scenario_id) {
    const sid = (scenario_id || "").toString().trim().toUpperCase();
    if (!sid) return;
    const url = `/assets/fbr_integration/scenario_docs/${sid}.json`;
    fetch(url)
        .then(function (r) {
            if (!r.ok) throw new Error("Not found: " + sid);
            return r.json();
        })
        .then(function (data) {
            const json_html = json_to_html(data, 0);
            const copy_id = "json-copy-" + sid;
            const raw_json = JSON.stringify(data, null, 2);
            const html = `
<div style="font-family:inherit;">
  <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;padding:10px 14px;
    background:linear-gradient(135deg,#0f172a,#1e3a5f);border-radius:10px;">
    <span style="background:#38bdf8;color:#0f172a;font-weight:700;padding:3px 10px;
      border-radius:999px;font-size:13px;">${esc(data.id || sid)}</span>
    <span style="font-size:15px;font-weight:700;color:#f1f5f9;">${esc(
        data.title || ""
    )}</span>
    <button id="${copy_id}" style="margin-left:auto;padding:4px 12px;background:#334155;color:#e2e8f0;
      border:1px solid #475569;border-radius:6px;cursor:pointer;font-size:12px;">Copy JSON</button>
  </div>
  <p style="color:#475569;margin-bottom:10px;font-size:13px;">${esc(
      data.description || ""
  )}</p>
  <div style="background:#0d1117;border:1px solid #30363d;border-radius:10px;
    padding:16px 18px;overflow-x:auto;max-height:55vh;overflow-y:auto;">
    <pre style="margin:0;font-family:'Fira Code','Cascadia Code','Consolas',monospace;
      font-size:12.5px;line-height:1.7;white-space:pre;">${json_html}</pre>
  </div>
</div>`;
            frappe.msgprint({
                title: __("{0} — {1}", [
                    esc(data.id || sid),
                    esc(data.title || ""),
                ]),
                indicator: "blue",
                message: html,
                wide: true,
            });
            // Attach copy handler after DOM render (onclick is stripped by Frappe sanitizer)
            setTimeout(function () {
                const btn = document.getElementById(copy_id);
                if (btn) {
                    btn.addEventListener("click", function () {
                        navigator.clipboard
                            .writeText(raw_json)
                            .then(function () {
                                btn.textContent = "Copied!";
                                setTimeout(function () {
                                    btn.textContent = "Copy JSON";
                                }, 1500);
                            });
                    });
                }
            }, 100);
        })
        .catch(function () {
            frappe.msgprint({
                title: __("Scenario Not Found"),
                indicator: "orange",
                message: __("Could not load details for scenario <b>{0}</b>.", [
                    esc(sid),
                ]),
            });
        });
}

function show_scenario_tree(scenario_id) {
    const sid = (scenario_id || "").toString().trim().toUpperCase();
    if (!sid) return;

    fetch_scenario_doc(sid)
        .then(function (data) {
            frappe.msgprint({
                title: __("Scenario Tree: {0}", [esc(sid)]),
                indicator: "blue",
                message: render_scenario_tree_html(data, sid),
                wide: true,
            });
        })
        .catch(function (err) {
            frappe.msgprint({
                title: __("Scenario Tree Not Available"),
                indicator: "orange",
                message: __("Could not load tree for scenario <b>{0}</b>.", [
                    esc(sid),
                ]),
            });
        });
}

function fetch_scenario_doc(scenario_id) {
    const sid = (scenario_id || "").toString().trim().toUpperCase();
    const url = `/assets/fbr_integration/scenario_docs/${sid}.json`;
    return fetch(url).then(function (r) {
        if (!r.ok) throw new Error("Not found: " + sid);
        return r.json();
    });
}

function build_scenario_table_rows(data, sid) {
    const sample = data.sample || {};
    const items = Array.isArray(sample.items) ? sample.items : [];
    const scenarioId = sample.scenarioId || data.id || sid;
    const invoiceType = sample.invoiceType || "";

    return items.length
        ? items
              .map(
                  (item) => `
<tr>
    <td style="padding:8px 10px;border:1px solid #dbeafe;white-space:nowrap;">${esc(
        scenarioId
    )}</td>
    <td style="padding:8px 10px;border:1px solid #dbeafe;white-space:nowrap;">${esc(
        data.title || "-"
    )}</td>
    <td style="padding:8px 10px;border:1px solid #dbeafe;white-space:nowrap;">${esc(
        invoiceType || "-"
    )}</td>
    <td style="padding:8px 10px;border:1px solid #dbeafe;white-space:nowrap;">${esc(
        item.hsCode || "-"
    )}</td>
    <td style="padding:8px 10px;border:1px solid #dbeafe;white-space:nowrap;">${esc(
        item.rate || "-"
    )}</td>
    <td style="padding:8px 10px;border:1px solid #dbeafe;white-space:nowrap;">${esc(
        item.uoM || "-"
    )}</td>
    <td style="padding:8px 10px;border:1px solid #dbeafe;white-space:nowrap;">${esc(
        item.saleType || "-"
    )}</td>
    <td style="padding:8px 10px;border:1px solid #dbeafe;white-space:nowrap;">${esc(
        item.sroScheduleNo || "-"
    )}</td>
    <td style="padding:8px 10px;border:1px solid #dbeafe;white-space:nowrap;">${esc(
        item.sroItemSerialNo || "-"
    )}</td>
</tr>`
              )
              .join("")
        : `<tr><td colspan="9" style="padding:12px;border:1px dashed #cbd5e1;color:#64748b;text-align:center;">No item data found in sample payload.</td></tr>`;
}

function render_scenario_tree_html(data, sid) {
    const rows = build_scenario_table_rows(data, sid);
    return `
<div style="font-family:inherit;line-height:1.5;">
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;padding:10px 14px;background:linear-gradient(135deg,#1f4e79,#2b6da8);border-radius:10px;">
        <span style="background:#fff;color:#1f4e79;font-weight:700;padding:3px 10px;border-radius:999px;font-size:13px;">${esc(
            data.id
        )}</span>
        <span style="font-size:14px;font-weight:700;color:#fff;">${esc(
            data.title || ""
        )}</span>
    </div>

    <div style="border:1px solid #c7d2fe;border-radius:10px;overflow:hidden;">
        <div style="padding:10px 14px;background:#eef2ff;font-size:12px;font-weight:700;color:#312e81;">Scenario Table</div>
        <div style="overflow:auto;">
            <table style="width:100%;border-collapse:collapse;min-width:1200px;font-size:12px;color:#0f172a;">
                <thead style="background:#e0e7ff;color:#312e81;">
                    <tr>
                        <th style="padding:8px 10px;border:1px solid #c7d2fe;">Scenario ID</th>
                        <th style="padding:8px 10px;border:1px solid #c7d2fe;">Title</th>
                        <th style="padding:8px 10px;border:1px solid #c7d2fe;">Invoice Type</th>
                        <th style="padding:8px 10px;border:1px solid #c7d2fe;">HS Code</th>
                        <th style="padding:8px 10px;border:1px solid #c7d2fe;">Rate</th>
                        <th style="padding:8px 10px;border:1px solid #c7d2fe;">UoM</th>
                        <th style="padding:8px 10px;border:1px solid #c7d2fe;">Sale Type</th>
                        <th style="padding:8px 10px;border:1px solid #c7d2fe;">SRO Schedule No</th>
                        <th style="padding:8px 10px;border:1px solid #c7d2fe;">SRO Item Serial No</th>
                    </tr>
                </thead>
                <tbody>
                    ${rows}
                </tbody>
            </table>
        </div>
    </div>
</div>`;
}

let fbrScenarioIndexCache = null;
let fbrScenarioIndexError = null;

function clear_fbr_scenario_cache() {
    fbrScenarioIndexCache = null;
    fbrScenarioIndexError = null;
    console.log("[FBR] Scenario index cache cleared");
}

function load_scenario_index() {
    if (Array.isArray(fbrScenarioIndexCache)) {
        return Promise.resolve(fbrScenarioIndexCache);
    }

    if (fbrScenarioIndexError) {
        return Promise.reject(fbrScenarioIndexError);
    }

    console.log(
        "[FBR] Loading scenario index from /assets/fbr_integration/scenario_docs/index.json"
    );

    return fetch("/assets/fbr_integration/scenario_docs/index.json")
        .then(function (r) {
            if (!r.ok) {
                const err = new Error(
                    `Failed to load scenario index: HTTP ${r.status} ${r.statusText}`
                );
                console.error("[FBR]", err.message);
                fbrScenarioIndexError = err;
                throw err;
            }
            return r.json();
        })
        .then(function (rows) {
            if (!Array.isArray(rows)) {
                const err = new Error(
                    "Scenario index is not an array: " + typeof rows
                );
                console.error("[FBR]", err.message);
                fbrScenarioIndexError = err;
                throw err;
            }
            fbrScenarioIndexCache = rows;
            console.log(`[FBR] Loaded ${rows.length} scenarios from index`);
            return fbrScenarioIndexCache;
        })
        .catch(function (err) {
            fbrScenarioIndexError = err;
            console.error(
                "[FBR] Scenario index load failed:",
                err.message || err
            );
            throw err;
        });
}

function show_scenario_browser(frm) {
    load_scenario_index()
        .then(function (rows) {
            const dialog = new frappe.ui.Dialog({
                title: __("Scenario Index"),
                size: "large",
                fields: [
                    {
                        fieldtype: "Data",
                        fieldname: "search",
                        label: __("Search"),
                        default: "",
                    },
                    {
                        fieldtype: "HTML",
                        fieldname: "results",
                    },
                ],
            });

            dialog.$wrapper.find(".modal-dialog").css({
                width: "96vw",
                "max-width": "96vw",
            });

            const render_rows = function (query) {
                const q = (query || "").toString().toLowerCase().trim();
                const filtered = rows.filter(function (row) {
                    const hay = `${row.id || ""} ${row.title || ""} ${
                        row.description || ""
                    }`
                        .toLowerCase()
                        .trim();
                    return !q || hay.includes(q);
                });

                const container = dialog.get_field("results").$wrapper;
                container.html(
                    `<div style="padding:14px;border:1px solid #bfdbfe;border-radius:10px;background:#eff6ff;color:#1d4ed8;font-size:12px;">
                        ${__("Loading scenario table...")}
                    </div>`
                );

                Promise.all(
                    filtered.map(function (row) {
                        return fetch_scenario_doc(row.id)
                            .then(function (data) {
                                return build_scenario_table_rows(data, row.id);
                            })
                            .catch(function () {
                                return "";
                            });
                    })
                ).then(function (tableRows) {
                    const htmlRows = tableRows.join("");
                    container.html(
                        filtered.length
                            ? `<div style="max-height:72vh;overflow:auto;padding-right:4px;">
<div style="padding:10px 14px;background:#eef2ff;font-size:12px;font-weight:700;color:#312e81;border:1px solid #c7d2fe;border-bottom:none;border-radius:10px 10px 0 0;">${__(
                                  "Scenario Table"
                              )}</div>
<table style="width:max-content;border-collapse:collapse;min-width:1550px;font-size:12px;color:#0f172a;">
  <thead style="position:sticky;top:0;background:#e0e7ff;z-index:1;color:#312e81;">
    <tr>
      <th style="padding:8px 10px;border:1px solid #c7d2fe;min-width:120px;">Scenario ID</th>
      <th style="padding:8px 10px;border:1px solid #c7d2fe;min-width:320px;">Title</th>
      <th style="padding:8px 10px;border:1px solid #c7d2fe;min-width:130px;">Invoice Type</th>
      <th style="padding:8px 10px;border:1px solid #c7d2fe;min-width:140px;">HS Code</th>
      <th style="padding:8px 10px;border:1px solid #c7d2fe;min-width:90px;">Rate</th>
      <th style="padding:8px 10px;border:1px solid #c7d2fe;min-width:210px;">UoM</th>
      <th style="padding:8px 10px;border:1px solid #c7d2fe;min-width:220px;">Sale Type</th>
      <th style="padding:8px 10px;border:1px solid #c7d2fe;min-width:220px;">SRO Schedule No</th>
      <th style="padding:8px 10px;border:1px solid #c7d2fe;min-width:180px;">SRO Item Serial No</th>
    </tr>
  </thead>
  <tbody>${
      htmlRows ||
      `<tr><td colspan="9" style="padding:12px;border:1px dashed #cbd5e1;color:#64748b;text-align:center;">${__(
          "No scenario rows available."
      )}</td></tr>`
  }</tbody>
</table>
</div>`
                            : `<div style="padding:12px;color:#777;">${__(
                                  "No scenarios matched your search."
                              )}</div>`
                    );
                });
            };

            dialog.show();
            render_rows("");

            dialog.get_field("search").$input.on("input", function () {
                render_rows($(this).val());
            });
        })
        .catch(function (err) {
            const errMsg = (err && err.message) || "Unknown error";
            console.error("[FBR] Scenario browser failed:", errMsg);
            frappe.msgprint({
                title: __("Scenario Index Not Available"),
                indicator: "red",
                message: `
<div style="font-size:13px;line-height:1.6;">
  <p><b>Could not load the FBR scenario catalog.</b></p>
  <p style="margin-top:8px;color:#666;font-size:12px;">${esc(errMsg)}</p>
  <p style="margin-top:12px;color:#333;">To resolve this issue:</p>
  <ol style="margin:8px 0;padding-left:20px;font-size:12px;">
    <li>Run: <code>fbr-build-scenarios</code></li>
    <li>Run: <code>bench build --app fbr_integration</code></li>
    <li>Run: <code>bench --site site1.local clear-cache</code></li>
    <li>Reload the page (Ctrl+Shift+R for hard refresh)</li>
  </ol>
  <p style="margin-top:8px;font-size:11px;color:#777;"><b>Debug:</b> Check browser console (F12) for logs with <code>[FBR]</code> prefix</p>
</div>`,
            });
        });
}

const FBR_PRINT_FORMAT = "FBR Sales Invoice";
const FBR_LOGO_URL = "/assets/fbr_integration/images/fbr/DI_invoicing.png";
const FBR_DEFAULT_SCENARIO = "Pakistan Tax";
const FBR_DEFAULT_INVOICE_TYPE = "Sale Invoice";
const FBR_DEFAULT_SCENARIO_DETAIL =
    "SN001 - Goods at Standard Rate (Registered Buyer)";
const fbrScenarioTemplateCache = new Map();

function normalize_fbr_text(value) {
    return (value || "")
        .toString()
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, " ")
        .replace(/\s+/g, " ")
        .trim();
}

function extract_fbr_scenario_id(value) {
    const text = (value || "").toString().trim().toUpperCase();
    const match = text.match(/^(SN\d{3})\b/);
    return match ? match[1] : "";
}

function get_effective_invoice_fbr_scenario(frm) {
    const detail = (frm.doc.custom_scenario_detail || "").toString().trim();
    if (detail) {
        return detail;
    }

    const scenarioId = (frm.doc.custom_scenario_id || "").toString().trim();
    return scenarioId;
}

function get_effective_fbr_scenario(frm) {
    return get_effective_invoice_fbr_scenario(frm);
}

function get_selected_scenario_id(frm) {
    const detail = (frm.doc.custom_scenario_detail || "").toString().trim();
    return (
        extract_fbr_scenario_id(detail) ||
        (frm.doc.custom_scenario_id || "").toString().trim()
    );
}

async function set_invoice_scenario_detail_by_id(frm, scenarioId) {
    const sid = (scenarioId || "").toString().trim().toUpperCase();
    if (!sid) return;

    const name = await resolve_scenario_detail_from_id(sid);
    if (name) {
        await frm.set_value("custom_scenario_detail", name);
    }
}

function resolve_scenario_detail_from_id(scenarioId) {
    const sid = (scenarioId || "").toString().trim().toUpperCase();
    if (!sid) return Promise.resolve("");

    return frappe.db
        .get_value("Scenario ID", { scenario_id: sid }, "name")
        .then((response) => {
            return (((response || {}).message || {}).name || "")
                .toString()
                .trim();
        });
}

async function sync_invoice_scenario_fields(frm) {
    const scenarioId = (frm.doc.custom_scenario_id || "").toString().trim();
    if (!scenarioId) return;

    const detail = await resolve_scenario_detail_from_id(scenarioId);
    if (
        detail &&
        (frm.doc.custom_scenario_detail || "").toString().trim() !== detail
    ) {
        await frm.set_value("custom_scenario_detail", detail);
    }
}

function render_scenario_detail_field_html(data, sid) {
    const sample = data.sample || {};
    const items = Array.isArray(sample.items) ? sample.items : [];
    const itemHtml = items.length
        ? items
              .map((item, idx) => {
                  return `
<div style="margin-top:10px;padding:10px;border:1px solid #c7d2fe;border-radius:8px;background:#fff;">
  <div style="font-size:12px;font-weight:700;color:#312e81;margin-bottom:8px;">Item ${
      idx + 1
  }</div>
  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:8px;">
    <div><div style="font-size:11px;color:#64748b;">HS Code</div><div style="font-size:12px;font-weight:600;">${esc(
        item.hsCode || ""
    )}</div></div>
    <div><div style="font-size:11px;color:#64748b;">Description</div><div style="font-size:12px;font-weight:600;">${esc(
        item.productDescription || ""
    )}</div></div>
    <div><div style="font-size:11px;color:#64748b;">Sale Type</div><div style="font-size:12px;font-weight:600;">${esc(
        item.saleType || ""
    )}</div></div>
    <div><div style="font-size:11px;color:#64748b;">UoM</div><div style="font-size:12px;font-weight:600;">${esc(
        item.uoM || ""
    )}</div></div>
    <div><div style="font-size:11px;color:#64748b;">Rate</div><div style="font-size:12px;font-weight:600;">${esc(
        item.rate || ""
    )}</div></div>
    <div><div style="font-size:11px;color:#64748b;">SRO Schedule No</div><div style="font-size:12px;font-weight:600;">${esc(
        item.sroScheduleNo || ""
    )}</div></div>
    <div><div style="font-size:11px;color:#64748b;">SRO Item Serial No</div><div style="font-size:12px;font-weight:600;">${esc(
        item.sroItemSerialNo || ""
    )}</div></div>
  </div>
</div>`;
              })
              .join("")
        : `<div style="margin-top:10px;padding:10px;border:1px dashed #cbd5e1;border-radius:8px;color:#64748b;">No item data found in sample payload.</div>`;

    return `
<div style="font-family:inherit;line-height:1.5;">
  <div style="display:flex;align-items:center;gap:10px;padding:10px 14px;background:linear-gradient(135deg,#0f172a,#1e3a5f);border-radius:10px;color:#f8fafc;">
    <span style="background:#38bdf8;color:#0f172a;font-weight:700;padding:3px 10px;border-radius:999px;font-size:13px;">${esc(
        data.id || sid
    )}</span>
    <span style="font-size:14px;font-weight:700;">${esc(
        data.title || ""
    )}</span>
    <button type="button" class="btn btn-xs btn-default" data-scenario-tree="${esc(
        sid
    )}" style="margin-left:auto;">Scenario Index</button>
  </div>
  <div style="margin-top:10px;padding:12px;border:1px solid #dbeafe;border-radius:10px;background:#f8fbff;">
    <div style="font-size:11px;font-weight:700;letter-spacing:.4px;text-transform:uppercase;color:#1d4ed8;margin-bottom:4px;">Description</div>
    <div style="font-size:13px;color:#1f2937;">${esc(
        data.description || ""
    )}</div>
  </div>
  <div style="margin-top:10px;display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:8px;">
    <div style="padding:10px;border:1px solid #e5e7eb;border-radius:8px;background:#fff;">
      <div style="font-size:11px;color:#64748b;">Invoice Type</div>
      <div style="font-size:12px;font-weight:600;">${esc(
          sample.invoiceType || ""
      )}</div>
    </div>
    <div style="padding:10px;border:1px solid #e5e7eb;border-radius:8px;background:#fff;">
      <div style="font-size:11px;color:#64748b;">Buyer Registration Type</div>
      <div style="font-size:12px;font-weight:600;">${esc(
          sample.buyerRegistrationType || ""
      )}</div>
    </div>
    <div style="padding:10px;border:1px solid #e5e7eb;border-radius:8px;background:#fff;">
      <div style="font-size:11px;color:#64748b;">Scenario ID</div>
      <div style="font-size:12px;font-weight:600;">${esc(
          sample.scenarioId || data.id || sid
      )}</div>
    </div>
    <div style="padding:10px;border:1px solid #e5e7eb;border-radius:8px;background:#fff;">
      <div style="font-size:11px;color:#64748b;">Items</div>
      <div style="font-size:12px;font-weight:600;">${items.length}</div>
    </div>
  </div>
  <div style="margin-top:10px;padding:10px;border:1px solid #c7d2fe;border-radius:10px;background:#eef2ff;">
    <div style="font-size:12px;font-weight:700;color:#312e81;margin-bottom:6px;">Selected Scenario Preview</div>
    ${itemHtml}
  </div>
</div>`;
}

async function render_selected_scenario_detail_fields(frm) {
    const html_field = scenario_detail_html_field(frm);
    if (!frm.fields_dict[html_field]) return;

    const sid = get_selected_scenario_id(frm);
    if (!sid) {
        frm.set_df_property(
            html_field,
            "options",
            '<div style="padding:10px;color:#64748b;">Select a scenario detail to preview its scenario JSON.</div>'
        );
        return;
    }

    try {
        const data = await fetch_scenario_doc(sid);
        // Render only the currently selected scenario so the form stays focused.
        frm.set_df_property(
            html_field,
            "options",
            render_scenario_detail_field_html(data, sid)
        );
        if (frm.fields_dict[html_field].$wrapper) {
            frm.fields_dict[html_field].$wrapper
                .find("[data-scenario-tree]")
                .on("click", function () {
                    show_scenario_tree(
                        (this.dataset || {}).scenarioTree || sid
                    );
                });
        }
    } catch (err) {
        frm.set_df_property(
            html_field,
            "options",
            `<div style="padding:10px;color:#b45309;">Scenario details not available for <b>${esc(
                sid
            )}</b>.</div>`
        );
    }
}

function bind_item_scenario_detail_preview(frm) {
    if (frappe.ui.form.__fbr_item_scenario_preview_bound) return;
    frappe.ui.form.__fbr_item_scenario_preview_bound = true;

    ["Sales Invoice Item", "POS Invoice Item"].forEach(function (doctype) {
        frappe.ui.form.on(doctype, {
            form_render(parentFrm, cdt, cdn) {
                render_item_scenario_detail_fields(parentFrm || frm, cdn);
            },
        });
    });
}

function set_html_control_content(control, html) {
    if (!control) return;
    if (control.df) {
        control.df.options = html || "";
    }
    if (typeof control.html === "function") {
        control.html(html || "");
        return;
    }
    const target =
        control.$wrapper && control.$wrapper.find(".html-value").length
            ? control.$wrapper.find(".html-value")
            : control.$wrapper;
    if (target) {
        target.html(html || "");
    }
}

function get_item_row(frm, cdn) {
    return (
        locals["Sales Invoice Item"]?.[cdn] ||
        locals["POS Invoice Item"]?.[cdn] ||
        (frm.doc.items || []).find((d) => d.name === cdn) ||
        null
    );
}

function get_item_html_control(frm, cdn) {
    const grid_row =
        frm.fields_dict.items &&
        frm.fields_dict.items.grid &&
        frm.fields_dict.items.grid.grid_rows_by_docname
            ? frm.fields_dict.items.grid.grid_rows_by_docname[cdn]
            : null;
    if (!grid_row) return { grid_row: null, control: null, fieldname: "" };

    const form_fields =
        (grid_row.grid_form && grid_row.grid_form.fields_dict) || {};
    const grid_fields = grid_row.on_grid_fields_dict || {};
    const fieldname = scenario_detail_html_field({
        fields_dict: Object.assign({}, grid_fields, form_fields),
    });
    const control = form_fields[fieldname] || grid_fields[fieldname] || null;
    return { grid_row, control, fieldname };
}

function copy_customer_fbr_links(frm, options) {
    options = options || {};
    if (!frm || !frm.doc || !frm.doc.customer) return;

    frappe.db.get_value(
        "Customer",
        frm.doc.customer,
        ["custom_buyer_province", "custom_tax_payer_type"],
        function (r) {
            if (!r) return;
            if (
                r.custom_buyer_province &&
                (!options.ifEmpty || !(frm.doc.custom_buyer_province || "").toString().trim())
            ) {
                frm.set_value("custom_buyer_province", r.custom_buyer_province);
            }
            if (
                r.custom_tax_payer_type &&
                (!options.ifEmpty || !(frm.doc.custom_tax_payer_type || "").toString().trim())
            ) {
                frm.set_value("custom_tax_payer_type", r.custom_tax_payer_type);
            }
        }
    );
}

function copy_item_fbr_links(frm, cdt, cdn) {
    const row = locals[cdt]?.[cdn] || get_item_row(frm, cdn);
    if (!row || !row.item_code) return;

    frappe.call({
        method: "fbr_integration.api.get_item_fbr_tax_defaults",
        args: {
            item_code: row.item_code,
            posting_date: frm.doc.posting_date,
            uom: row.uom,
            company: frm.doc.company,
            currency: frm.doc.currency,
            qty: row.qty,
            rate: row.rate,
            amount: row.amount,
        },
        callback: function (r) {
            const data = (r && r.message) || {};
            const fields = [
                "custom_hs_code",
                "custom_fbr_uom",
                "custom_fbr_tax_profile",
                "custom_fbr_tax_calculation_basis",
                "custom_fbr_retail_price",
                "custom_fbr_fixed_notified_value",
                "custom_fbr_taxable_value",
                "custom_sale_type",
                "custom_sro_schedule_no",
                "custom_sro_item_sno",
            ];
            fields.forEach(function (field) {
                if (data[field] === undefined || data[field] === null || data[field] === "") {
                    return;
                }
                if (
                    field === "custom_sale_type" &&
                    (row.custom_sale_type || "").toString().trim() &&
                    (row.custom_sale_type || "").toString().trim() !==
                        "Goods at standard rate (default)"
                ) {
                    return;
                }
                if (
                    (field === "custom_sro_schedule_no" || field === "custom_sro_item_sno") &&
                    (row[field] || "").toString().trim()
                ) {
                    return;
                }
                frappe.model.set_value(cdt, cdn, field, data[field]);
            });
            recalc_fbr_item_row(frm, cdt, cdn);
        },
    });
}

async function render_item_scenario_detail_fields(frm, cdn, attempt) {
    attempt = attempt || 0;
    const row = get_item_row(frm, cdn);
    if (!row) return;

    const { grid_row, control } = get_item_html_control(frm, cdn);
    if (!control) {
        if (attempt < 8) {
            setTimeout(function () {
                render_item_scenario_detail_fields(frm, cdn, attempt + 1);
            }, 80);
        }
        return;
    }

    const rowDetail = (row.custom_scenario_detail || "").toString().trim();
    const parentDetail = (frm.doc.custom_scenario_detail || "")
        .toString()
        .trim();
    const sid =
        extract_fbr_scenario_id(rowDetail) ||
        extract_fbr_scenario_id(parentDetail) ||
        (row.custom_scenario_id || "").toString().trim().toUpperCase() ||
        (frm.doc.custom_scenario_id || "").toString().trim().toUpperCase();

    if (!sid) {
        set_html_control_content(
            control,
            '<div style="padding:10px;color:#64748b;">Select a scenario detail to preview its scenario JSON.</div>'
        );
        return;
    }

    try {
        const data = await fetch_scenario_doc(sid);
        const liveRow = get_item_row(frm, cdn) || row;
        const currentSid = extract_fbr_scenario_id(
            liveRow.custom_scenario_detail
        );
        if (currentSid && currentSid !== sid) return;

        set_html_control_content(
            control,
            render_scenario_detail_field_html(data, sid)
        );

        const wrapper =
            control.$wrapper ||
            (grid_row && grid_row.grid_form && grid_row.grid_form.wrapper) ||
            (grid_row && grid_row.wrapper);
        if (wrapper) {
            wrapper
                .find("[data-scenario-tree]")
                .off("click")
                .on("click", function () {
                    show_scenario_tree(
                        (this.dataset || {}).scenarioTree || sid
                    );
                });
        }
    } catch (err) {
        set_html_control_content(
            control,
            `<div style="padding:10px;color:#b45309;">Scenario details not available for <b>${esc(
                sid
            )}</b>.</div>`
        );
    }
}

function render_all_item_scenario_detail_fields(frm) {
    (frm.doc.items || []).forEach(function (row) {
        render_item_scenario_detail_fields(frm, row.name);
    });
}

function should_force_apply_scenario(options = {}) {
    return options.forceApply === true;
}

function is_return_checked(doc) {
    return Number((doc && doc.is_return) || 0) === 1;
}

async function ensure_sale_invoice_fbr_defaults(frm) {
    if (!frm || !frm.doc || cint(frm.doc.docstatus) !== 0) return;

    if (
        !is_return_checked(frm.doc) &&
        !(frm.doc.custom_invoice_type || "").toString().trim()
    ) {
        await frm.set_value("custom_invoice_type", FBR_DEFAULT_INVOICE_TYPE);
    }

    if (!(frm.doc.custom_scenario_detail || "").toString().trim()) {
        await frm.set_value(
            "custom_scenario_detail",
            FBR_DEFAULT_SCENARIO_DETAIL
        );
    }
}

async function ensure_return_credit_note(frm, options = {}) {
    if (!frm || !frm.doc) return;

    if (!is_return_checked(frm.doc)) return;

    const currentType = (frm.doc.custom_invoice_type || "").toString().trim();
    if (currentType === "Credit Note") return;

    await frm.set_value("custom_invoice_type", "Credit Note");

    if (options.notify === true) {
        frappe.show_alert({
            message: __(
                "Invoice Type was set to Credit Note because this is a return invoice."
            ),
            indicator: "blue",
        });
    }
}

const FBR_ERROR_RESPONSE_FIELDS = [
    "custom_fbr_digital_invoice_response",
    "custom_fbr_invoice_no",
    "custom_fbr_responsed",
    "custom_fbr_qr_code",
    "custom_qr_code",
    "custom_fbr_invoice_status",
    "custom_fbr_invoice_status_code",
    "custom_fbr_invoice_error",
    "custom_fbr_invoice_error_code",
    "custom_fbr_submission_time",
    "custom_fbr_invoice_statuses",
    "custom_fbr_invoice_item_no",
    "custom_fbr_status",
    "custom_fbr_invoice_number",
    "custom_fbr_datetime",
];

function invoice_has_fbr_error(frm) {
    if (!frm || !frm.doc) return false;
    const responded = (frm.doc.custom_fbr_responsed || "").toString().trim();
    const statusCode = (frm.doc.custom_fbr_invoice_status_code || "")
        .toString()
        .trim();
    const response = (
        frm.doc.custom_fbr_digital_invoice_response || ""
    )
        .toString()
        .trim();
    const error = (frm.doc.custom_fbr_invoice_error || "").toString().trim();
    if (responded.toLowerCase() === "error") return true;
    if (statusCode && statusCode !== "00") return true;
    if (error) return true;
    if (response && responded.toLowerCase() !== "success") return true;
    return false;
}

async function clear_fbr_response_fields(frm) {
    if (!frm || !frm.doc) return;

    for (const field of FBR_ERROR_RESPONSE_FIELDS) {
        if (field in frm.doc && frm.doc[field]) {
            await frm.set_value(field, "");
        }
    }
}

function clear_fbr_error_on_form(frm) {
    if (!frm || !frm.doc || !frm.doc.name) return;

    frappe.confirm(
        __("Clear all FBR error and response fields on this invoice?"),
        function () {
            frappe.call({
                method: "fbr_integration.handler.clear_fbr_error_fields",
                args: { name: frm.doc.name, doctype: frm.doc.doctype },
                freeze: true,
                freeze_message: __("Clearing FBR error fields..."),
                callback: function (r) {
                    const msg = (r && r.message) || {};
                    frm.reload_doc().then(function () {
                        frappe.show_alert({
                            message: msg.message || __("FBR error fields cleared."),
                            indicator: "green",
                        });
                    });
                },
            });
        }
    );
}

async function sync_return_source_invoice_no(frm) {
    if (!frm || !frm.doc) return;
    if (!is_return_checked(frm.doc)) return;

    const linkedInvoice = (frm.doc.return_against || "").toString().trim();
    if (!linkedInvoice) return;

    let fbrNo = "";
    for (const dt of ["Sales Invoice", "POS Invoice"]) {
        try {
            const r = await frappe.db.get_value(
                dt,
                linkedInvoice,
                "custom_fbr_invoice_no"
            );
            fbrNo = ((r && r.message && r.message.custom_fbr_invoice_no) || "")
                .toString()
                .trim();
            if (fbrNo) break;
        } catch (e) {
            // Missing doctype/field/doc — try the other invoice type.
        }
    }

    if (
        (frm.doc.custom_fbr_source_invoice_no || "").toString().trim() !== fbrNo
    ) {
        await frm.set_value("custom_fbr_source_invoice_no", fbrNo);
    }
}

async function resolve_fbr_item_tax_template(scenario, company) {
    const scenarioKey = normalize_fbr_text(scenario);
    const companyKey = normalize_fbr_text(company);
    const key = `${companyKey}::${scenarioKey}`;

    if (!scenarioKey && !companyKey) {
        return "";
    }

    if (!fbrScenarioTemplateCache.has(key)) {
        fbrScenarioTemplateCache.set(
            key,
            frappe
                .call({
                    method: "fbr_integration.api.resolve_item_tax_template_name",
                    args: {
                        scenario: scenario || "",
                        company: company || "",
                    },
                })
                .then((r) => (r.message || "").toString().trim())
        );
    }

    return await fbrScenarioTemplateCache.get(key);
}

async function apply_fbr_item_tax_template(frm, cdt, cdn, options = {}) {
    const localTable = (cdt && locals[cdt]) || {};
    const explicitRow = options.row || null;
    const row =
        explicitRow ||
        localTable[cdn] ||
        (frm.doc.items || []).find((d) => d.name === cdn);
    if (!row) return "";

    const forceApply = should_force_apply_scenario(options);
    const scenario = get_effective_fbr_scenario(frm);
    const templateName = await resolve_fbr_item_tax_template(
        scenario,
        frm.doc.company
    );
    const currentTemplate = (row.item_tax_template || "").toString().trim();

    if (templateName) {
        if (forceApply || !currentTemplate) {
            await frappe.model.set_value(
                cdt,
                cdn,
                "item_tax_template",
                templateName
            );
            return templateName;
        }
        return currentTemplate;
    }

    // Keep manual template selection when no scenario mapping exists.
    if (currentTemplate) {
        return currentTemplate;
    }

    return "";
}

async function sync_fbr_item_tax_templates(frm, options = {}) {
    const targets = (frm.doc.items || [])
        .map((row) => ({
            cdt: row.doctype || "Sales Invoice Item",
            cdn: row.name,
            row,
        }))
        .filter((d) => d.cdn);

    const forceApply = should_force_apply_scenario(options);
    const changedTargets = [];

    for (const target of targets) {
        const scenario = get_effective_fbr_scenario(frm);
        const templateName = await resolve_fbr_item_tax_template(
            scenario,
            frm.doc.company
        );

        const currentTemplate = (target.row.item_tax_template || "")
            .toString()
            .trim();
        const nextTemplate = (templateName || "").toString().trim();

        if (!nextTemplate) continue;

        if (forceApply || !currentTemplate) {
            target.row.item_tax_template = nextTemplate;
            changedTargets.push(target);
        }
    }

    if (changedTargets.length) {
        frm.dirty();
        frm.refresh_field("items");

        for (const target of changedTargets) {
            recalc_fbr_item_row(frm, target.cdt, target.cdn);
        }
    }
}

async function apply_invoice_scenario_to_all_items(frm, options = {}) {
    const forceApply = should_force_apply_scenario(options);
    const rows = [...(frm.doc.items || [])];
    if (!rows.length) return;

    const scenario = get_effective_invoice_fbr_scenario(frm);
    const templateName = await resolve_fbr_item_tax_template(
        scenario,
        frm.doc.company
    );
    const targetTemplate = (templateName || "").toString().trim();
    const parentDetail = (frm.doc.custom_scenario_detail || "")
        .toString()
        .trim();
    const changedTargets = [];

    frm.__fbr_bulk_updating = true;
    try {
        for (const row of rows) {
            const cdt = row.doctype || "Sales Invoice Item";
            const cdn = row.name;
            const current = (row.item_tax_template || "").toString().trim();
            if (
                parentDetail &&
                (forceApply ||
                    !(row.custom_scenario_detail || "").toString().trim())
            ) {
                await frappe.model.set_value(
                    cdt,
                    cdn,
                    "custom_scenario_detail",
                    parentDetail
                );
            }
            if (!targetTemplate) {
                continue;
            }

            if (forceApply ? current !== targetTemplate : !current) {
                await frappe.model.set_value(
                    cdt,
                    cdn,
                    "item_tax_template",
                    targetTemplate
                );
                changedTargets.push({ cdt, cdn });
            }
        }
    } finally {
        frm.__fbr_bulk_updating = false;
    }

    if (changedTargets.length) {
        frm.refresh_field("items");
        for (const target of changedTargets) {
            recalc_fbr_item_row(frm, target.cdt, target.cdn);
        }
    }
}

function setv(cdt, cdn, field, value) {
    frappe.model.set_value(cdt, cdn, field, value || 0);
}

function matches(tt, keys) {
    return keys.some((k) => tt.includes(k));
}

function sum_st_withheld(frm) {
    let total = 0;
    (frm.doc.items || []).forEach((row) => {
        total += parseFloat(row.custom_sales_tax_withheld_at_source) || 0;
    });
    if ("custom_sales_tax_withheld_at_source" in (frm.doc || {})) {
        frm.set_value("custom_sales_tax_withheld_at_source", total);
    }
}

function get_fbr_taxable_value(row) {
    const qty = parseFloat(row.qty) || 0;
    const rate = parseFloat(row.rate) || 0;
    const amount =
        parseFloat(row.amount) || qty * rate;
    const basis = (row.custom_fbr_tax_calculation_basis || "").toString().trim();
    if (basis === "Retail Price / MRP") {
        const mrp = parseFloat(row.custom_fbr_retail_price) || 0;
        return mrp > 0 ? mrp * qty : amount;
    }
    if (basis === "Fixed / Notified Value") {
        const notified = parseFloat(row.custom_fbr_fixed_notified_value) || 0;
        return notified > 0 ? notified * qty : amount;
    }
    if (basis === "Manual Taxable Value") {
        return parseFloat(row.custom_fbr_taxable_value) || amount;
    }
    return amount;
}

function apply_st_withheld_amount(frm, cdt, cdn, amount) {
    const row = locals[cdt][cdn];
    const withheldRate = parseFloat(row.custom_sales_tax_withheld_rate) || 0;
    const withheld = (amount * withheldRate) / 100;
    setv(cdt, cdn, "custom_sales_tax_withheld_at_source", withheld);
    sum_st_withheld(frm);
}

function recalc_fbr_item_row(frm, cdt, cdn) {
    const row = locals[cdt][cdn];
    const qty = parseFloat(row.qty) || 0;
    const rate = parseFloat(row.rate) || 0;
    const amount = qty * rate;
    const taxable = get_fbr_taxable_value(row);

    // Keep commercial amount on qty * rate for live preview; server remains authoritative.
    setv(cdt, cdn, "amount", amount);
    if ("custom_fbr_taxable_value" in row || row.custom_fbr_tax_calculation_basis) {
        setv(cdt, cdn, "custom_fbr_taxable_value", taxable);
    }

    setv(cdt, cdn, "custom_sales_tax_rate", 0);
    setv(cdt, cdn, "custom_further_tax_rate", 0);
    setv(cdt, cdn, "custom_extra_tax_rate", 0);

    setv(cdt, cdn, "custom_sales_tax", 0);
    setv(cdt, cdn, "custom_further_tax", 0);
    setv(cdt, cdn, "custom_extra_tax", 0);

    setv(cdt, cdn, "custom_total_tax_amount", 0);
    setv(cdt, cdn, "custom_tax_inclusive_amount", amount);
    apply_st_withheld_amount(frm, cdt, cdn, amount);

    if (!row.item_tax_template) {
        frm.refresh_field("items");
        return;
    }

    frappe.call({
        method: "fbr_integration.api.get_item_tax_template_rates",
        args: { template_name: row.item_tax_template },
        callback: function (r) {
            const res = r.message || [];
            if (!res.length) {
                frm.refresh_field("items");
                return;
            }

            let salesRate = 0,
                furtherRate = 0,
                extraRate = 0;

            res.forEach((tax) => {
                const tt = (tax.tax_type || "").toLowerCase();
                const rr = tax.tax_rate || 0;

                if (
                    matches(tt, [
                        "general sales tax",
                        "sales tax",
                        "gst",
                        "output tax",
                        "vat",
                    ])
                )
                    salesRate = rr;
                else if (matches(tt, ["further tax"])) furtherRate = rr;
                else if (matches(tt, ["extra tax"])) extraRate = rr;
            });

            if (res.length === 1 && salesRate === 0)
                salesRate = res[0].tax_rate || 0;

            const liveRow = locals[cdt][cdn] || row;
            const liveTaxable = get_fbr_taxable_value(liveRow);
            const liveAmount =
                parseFloat(liveRow.amount) ||
                (parseFloat(liveRow.qty) || 0) * (parseFloat(liveRow.rate) || 0);
            const sales = (liveTaxable * salesRate) / 100;
            const further = (liveAmount * furtherRate) / 100;
            const extra = (liveAmount * extraRate) / 100;

            setv(cdt, cdn, "custom_sales_tax_rate", salesRate);
            setv(cdt, cdn, "custom_further_tax_rate", furtherRate);
            setv(cdt, cdn, "custom_extra_tax_rate", extraRate);
            setv(cdt, cdn, "custom_fbr_taxable_value", liveTaxable);

            setv(cdt, cdn, "custom_sales_tax", sales);
            setv(cdt, cdn, "custom_further_tax", further);
            setv(cdt, cdn, "custom_extra_tax", extra);

            const totalTax = sales + further + extra;
            setv(cdt, cdn, "custom_total_tax_amount", totalTax);
            setv(cdt, cdn, "custom_tax_inclusive_amount", liveAmount + totalTax);
            apply_st_withheld_amount(frm, cdt, cdn, liveAmount);

            frm.refresh_field("items");
        },
    });
}

function sync_qr_field_on_form(frm) {
    const fbrNo = (frm.doc.custom_fbr_invoice_no || "").trim();
    if (!fbrNo) return;

    // Only update in-memory for display; don't mark submitted forms as dirty
    if (
        "custom_fbr_qr_code" in frm.doc &&
        (frm.doc.custom_fbr_qr_code || "") !== fbrNo
    ) {
        frm.doc.custom_fbr_qr_code = fbrNo;
    }
    if (
        "custom_qr_code" in frm.doc &&
        (frm.doc.custom_qr_code || "") !== fbrNo
    ) {
        frm.doc.custom_qr_code = fbrNo;
    }
}

function render_qr_preview(frm) {
    if (!frm.fields_dict.custom_qr_code) return;
    const fbrNo = (frm.doc.custom_fbr_invoice_no || "").trim();
    if (!fbrNo) {
        frm.set_df_property(
            "custom_qr_code",
            "options",
            '<div class="text-muted">QR will appear after FBR Invoice No is generated.</div>'
        );
        return;
    }

    const showHtml = (src) => {
        frm.set_df_property(
            "custom_qr_code",
            "options",
            `<div style="padding:6px 0;"><img src="${src}" style="width:170px;height:170px;border:1px solid #e5e7eb;padding:6px;border-radius:8px;background:#fff;" /><div style="margin-top:6px;font-size:12px;color:#6b7280;">${esc(
                fbrNo
            )}</div></div>`
        );
    };

    if (frm.doc.name && !frm.is_new()) {
        frappe.call({
            method: "fbr_integration.handler.get_fbr_codes",
            args: { name: frm.doc.name },
            callback: function (r) {
                const msg = r.message || {};
                if (msg.ok && msg.qr_data_url) {
                    showHtml(msg.qr_data_url);
                    return;
                }
                const fallback = `https://api.qrserver.com/v1/create-qr-code/?size=170x170&data=${encodeURIComponent(
                    fbrNo
                )}`;
                showHtml(fallback);
            },
        });
    } else {
        const fallback = `https://api.qrserver.com/v1/create-qr-code/?size=170x170&data=${encodeURIComponent(
            fbrNo
        )}`;
        showHtml(fallback);
    }
}

function get_print_url(frm) {
    // FBR Sales Invoice print view
    return `/printview?doctype=Sales%20Invoice&name=${encodeURIComponent(
        frm.doc.name
    )}&trigger_print=1&format=${encodeURIComponent(
        FBR_PRINT_FORMAT
    )}&no_letterhead=0`;
}

function get_pdf_url(frm) {
    // FBR Sales Invoice PDF download
    return `/api/method/frappe.utils.print_format.download_pdf?doctype=Sales%20Invoice&name=${encodeURIComponent(
        frm.doc.name
    )}&format=${encodeURIComponent(FBR_PRINT_FORMAT)}&no_letterhead=0`;
}

async function show_success_popup_with_qr_barcode(frm) {
    const r = await frappe.call({
        method: "fbr_integration.handler.get_fbr_codes",
        args: { name: frm.doc.name },
    });

    const data = r.message || {};
    const fbrNo = (frm.doc.custom_fbr_invoice_no || "").trim();
    const qrSrc =
        data.qr_data_url ||
        `https://api.qrserver.com/v1/create-qr-code/?size=170x170&data=${encodeURIComponent(
            fbrNo || frm.doc.name
        )}`;

    const print_url = get_print_url(frm);
    const pdf_url = get_pdf_url(frm);

    const stripHtml = (val) =>
        (val || "")
            .toString()
            .replace(/<[^>]*>/g, "")
            .replace(/\s+/g, " ")
            .trim();

    const asCurrencyText = (val) => {
        if (val == null) return "N/A";
        return stripHtml(frappe.format(val, { fieldtype: "Currency" }));
    };

    const taxAmount =
        frm.doc.total_taxes_and_charges != null
            ? asCurrencyText(frm.doc.total_taxes_and_charges)
            : "N/A";
    const totalAmount =
        frm.doc.total != null ? asCurrencyText(frm.doc.total) : "N/A";
    const grandTotal =
        frm.doc.grand_total != null
            ? asCurrencyText(frm.doc.grand_total)
            : "N/A";

    frappe.msgprint({
        title: __("Invoice Sent"),
        message: `
            <div style="font-size:13px; line-height:1.5; color:#1f2937; background:#edf7f2; padding:14px; border-radius:10px;">
                <div style="display:flex; align-items:center; gap:8px; color:#218653; font-weight:700; font-size:15px; margin-bottom:12px;">
                    <span style="display:inline-flex; width:20px; height:20px; border-radius:50%; background:#218653; color:#fff; align-items:center; justify-content:center; font-size:12px;">✓</span>
                    <span>Invoice Successfully Reported</span>
                </div>

                <div style="display:flex; justify-content:center; margin-bottom:12px;">
                    <div style="display:flex; gap:8px; padding:8px; border:2px solid #38a169; border-radius:10px; background:#fff; box-shadow:0 2px 8px rgba(0,0,0,.08);">
                        <div style="width:128px; height:128px; border:1px solid #e5e7eb; border-radius:6px; display:flex; align-items:center; justify-content:center; background:#f8fafc; overflow:hidden;">
                            <img src="${FBR_LOGO_URL}" alt="FBR Digital Invoicing" style="max-width:100%; max-height:100%; object-fit:contain;" onerror="this.style.display='none'" />
                        </div>
                        <div style="width:128px; height:128px; border:1px solid #e5e7eb; border-radius:6px; display:flex; align-items:center; justify-content:center; background:#fff; overflow:hidden;">
                            <img src="${qrSrc}" alt="FBR QR" style="width:120px; height:120px; object-fit:contain; display:block;" />
                        </div>
                    </div>
                </div>

                <div style="background:#2ea86d; color:#fff; border-radius:999px; padding:8px 14px; font-weight:700; text-align:center; letter-spacing:.2px; margin-bottom:8px;">
                    FBR INVOICE: ${esc(fbrNo || "N/A")}
                </div>

                <div style="background:#0f766e; color:#fff; border-radius:999px; padding:8px 14px; font-weight:700; text-align:center; letter-spacing:.2px; margin-bottom:10px;">
                    ERP INVOICE: ${esc(frm.doc.name || "N/A")}
                </div>

                <div style="background:#fff; border:1px solid #d1fae5; border-radius:8px; padding:8px 12px; margin-bottom:10px; font-size:12px;">
                    <table style="width:100%; border-collapse:collapse;">
                        <tr style="border-bottom:1px solid #e5e7eb;">
                            <td style="padding:4px 6px; color:#6b7280; width:48%;">📅 Date</td>
                            <td style="padding:4px 6px; font-weight:600; text-align:right;">${esc(
                                frm.doc.posting_date || ""
                            )}</td>
                        </tr>
                        <tr style="border-bottom:1px solid #e5e7eb;">
                            <td style="padding:4px 6px; color:#6b7280;">👤 Customer</td>
                            <td style="padding:4px 6px; font-weight:600; text-align:right;">${esc(
                                frm.doc.customer_name || frm.doc.customer || ""
                            )}</td>
                        </tr>
                        <tr style="border-bottom:1px solid #e5e7eb;">
                            <td style="padding:4px 6px; color:#6b7280;">💰 Total Amount</td>
                            <td style="padding:4px 6px; font-weight:600; text-align:right;">${esc(
                                totalAmount
                            )}</td>
                        </tr>
                        <tr style="border-bottom:1px solid #e5e7eb;">
                            <td style="padding:4px 6px; color:#6b7280;">🧾 Tax Amount</td>
                            <td style="padding:4px 6px; font-weight:600; text-align:right;">${esc(
                                taxAmount
                            )}</td>
                        </tr>
                        <tr>
                            <td style="padding:4px 6px; color:#166534; font-weight:700;">✅ Grand Total</td>
                            <td style="padding:4px 6px; font-weight:700; color:#166534; text-align:right;">${esc(
                                grandTotal
                            )}</td>
                        </tr>
                    </table>
                </div>

                <div style="display:flex; gap:8px; flex-wrap:wrap; justify-content:center; margin-bottom:10px;">
                    <a class="btn btn-sm" href="${print_url}" target="_blank" style="background:#166534; color:#fff; border:none; padding:7px 12px; border-radius:6px; text-decoration:none; font-weight:600;">
                        Print
                    </a>
                    <a class="btn btn-sm" href="${pdf_url}" target="_blank" style="background:#2563eb; color:#fff; border:none; padding:7px 12px; border-radius:6px; text-decoration:none; font-weight:600;">
                        Download PDF
                    </a>
                    <button class="btn btn-sm" id="btn_open_invoice" style="background:#475569; color:#fff; border:none; padding:7px 12px; border-radius:6px; font-weight:600;">
                        Open Invoice
                    </button>
                </div>

                ${
                    data.ok && data.barcode_data_url
                        ? `
                <div style="background:#fff; border:1px solid #d1fae5; border-radius:8px; padding:10px 10px 6px;">
                    <img src="${
                        data.barcode_data_url
                    }" style="width:100%; height:60px; display:block; object-fit:fill;" />
                    <div style="margin-top:4px; font-size:10px; letter-spacing:0.8px; color:#374151; text-align:center; word-break:break-all; font-weight:600;">
                        ${esc(data.value || fbrNo)}
                    </div>
                </div>
                `
                        : ""
                }
            </div>
        `,
        indicator: "green",
    });

    // attach open invoice action
    setTimeout(() => {
        const btn = document.getElementById("btn_open_invoice");
        if (btn) {
            btn.onclick = () =>
                frappe.set_route("Form", "Sales Invoice", frm.doc.name);
        }
    }, 200);
}


function sync_item_apply_tds_from_parent(frm) {
	const checked = cint(frm.doc.apply_tds) ? 1 : 0;
	(frm.doc.items || []).forEach((row) => {
		if (cint(row.apply_tds) === checked) return;
		frappe.model.set_value(row.doctype, row.name, "apply_tds", checked);
	});
	frm.refresh_field("items");
}

function register_fbr_invoice_form_handlers(doctype) {
frappe.ui.form.on(doctype, {
    async setup(frm) {
        if (frm.is_new()) {
            await ensure_sale_invoice_fbr_defaults(frm);
            await ensure_return_credit_note(frm);
            await sync_return_source_invoice_no(frm);
            await clear_fbr_response_fields(frm);
        }
        bind_item_scenario_detail_preview(frm);
    },

    apply_tds(frm) {
        if (!frm.fields_dict.apply_tds) return;
        sync_item_apply_tds_from_parent(frm);
        if (frm.fields_dict.tax_withholding_entries) {
            frm.clear_table("tax_withholding_entries");
            frm.refresh_field("tax_withholding_entries");
        }
    },

    custom_clear_fbr_error(frm) {
        clear_fbr_error_on_form(frm);
    },

    customer(frm) {
        copy_customer_fbr_links(frm);
        if (!frm.fields_dict.apply_tds) return;
        setTimeout(() => sync_item_apply_tds_from_parent(frm), 400);
    },

    custom_buyer_province(frm) {
        // FBR buyerProvince is sent from Territory — keep it aligned with Buyer Province.
        const province = (frm.doc.custom_buyer_province || "").trim();
        if (province && frm.doc.territory !== province) {
            frm.set_value("territory", province);
        }
    },

    territory(frm) {
        const territory = (frm.doc.territory || "").trim();
        if (!territory || frm.doc.custom_buyer_province) {
            return;
        }
        frappe.db.exists("Buyer Province", territory).then((exists) => {
            if (exists) {
                frm.set_value("custom_buyer_province", territory);
            }
        });
    },

    async is_return(frm) {
        await ensure_return_credit_note(frm, { notify: true });
        await sync_return_source_invoice_no(frm);
        if (is_return_checked(frm.doc)) {
            await clear_fbr_response_fields(frm);
        }
    },

    async return_against(frm) {
        await sync_return_source_invoice_no(frm);
        if (is_return_checked(frm.doc)) {
            await clear_fbr_response_fields(frm);
        }
    },

    async custom_invoice_type(frm) {
        await ensure_return_credit_note(frm, { notify: true });
    },

    async validate(frm) {
        await ensure_return_credit_note(frm);
        await sync_return_source_invoice_no(frm);

        if (
            is_return_checked(frm.doc) &&
            (frm.doc.custom_invoice_type || "").toString().trim() !==
                "Credit Note"
        ) {
            frappe.throw(
                __(
                    "When Is Return is checked, Invoice Type must be Credit Note."
                )
            );
        }
    },

    async custom_scenario_detail(frm) {
        const scenarioName = (frm.doc.custom_scenario_detail || "")
            .toString()
            .trim();
        const scenarioId = extract_fbr_scenario_id(scenarioName);
        if (
            scenarioId &&
            (frm.doc.custom_scenario_id || "").toString().trim() !== scenarioId
        ) {
            await frm.set_value("custom_scenario_id", scenarioId);
        }
        await apply_invoice_scenario_to_all_items(frm, {
            notify: true,
            forceApply: true,
        });
        await render_selected_scenario_detail_fields(frm);
        render_all_item_scenario_detail_fields(frm);
    },

    async custom_scenario_id(frm) {
        await set_invoice_scenario_detail_by_id(
            frm,
            frm.doc.custom_scenario_id
        );
        await apply_invoice_scenario_to_all_items(frm, {
            notify: true,
            forceApply: true,
        });
        await render_selected_scenario_detail_fields(frm);
        render_all_item_scenario_detail_fields(frm);
    },

    refresh(frm) {
        if (frm.doc.docstatus === 0) {
            copy_customer_fbr_links(frm, { ifEmpty: true });
            ensure_sale_invoice_fbr_defaults(frm).then(function () {
                apply_invoice_scenario_to_all_items(frm, { forceApply: false });
            });
        }
        if (frm.doc.docstatus === 0 && frm.fields_dict.apply_tds && !cint(frm.doc.apply_tds)) {
            sync_item_apply_tds_from_parent(frm);
        }
        sync_qr_field_on_form(frm);
        sync_return_source_invoice_no(frm);
        render_qr_preview(frm);
        sync_invoice_scenario_fields(frm);
        render_selected_scenario_detail_fields(frm);
        bind_item_scenario_detail_preview(frm);
        render_all_item_scenario_detail_fields(frm);

        frm.add_custom_button(__("Scenario Index"), function () {
            show_scenario_browser(frm);
        });

        if (invoice_has_fbr_error(frm)) {
            const clearBtn = frm.add_custom_button(
                __("Clear FBR Error"),
                function () {
                    clear_fbr_error_on_form(frm);
                }
            );
            try {
                clearBtn
                    .removeClass("btn-default btn-primary btn-success btn-purple")
                    .addClass("btn-danger");
            } catch (e) {
                // ignore style application errors
            }
        }

        // Determine if invoice is already submitted to FBR
        const is_sent_to_fbr = (frm.doc.custom_fbr_invoice_no || "").trim();

        // Cached settings — avoid one get_value per Sales Invoice refresh
        get_fbr_invoice_settings().then(function (settings) {
                const integration_type = (
                    (settings || {}).integration_type || ""
                ).trim();
                const is_sandbox = integration_type === "Sandbox";
                const is_submitted = frm.doc.docstatus === 1;

                // Sandbox: show on Draft + Submitted; Production: Submitted only
                if (!is_sandbox && !is_submitted) return;

                // Single "Send to FBR" button with dynamic styling
                const button_text = is_sent_to_fbr
                    ? __("✓ Sent to FBR")
                    : is_sandbox && !is_submitted
                    ? __("Send to FBR (Sandbox Test)")
                    : __("Send to FBR");

                const btn = frm.add_custom_button(
                    button_text,
                    async function () {
                        // If already sent -> show success popup with QR/barcode
                        if (is_sent_to_fbr) {
                            await show_success_popup_with_qr_barcode(frm);
                            return;
                        }

                        // If not sent -> send to FBR
                        frappe.call({
                            method: "fbr_integration.handler.send_to_fbr_si",
                            args: { name: frm.doc.name },
                            freeze: true,
                            callback: function (r) {
                                const resp = r.message || {};
                                if (resp.already_sent) {
                                    frm.reload_doc();
                                    return;
                                }

                                frm.reload_doc().then(() => {
                                    setTimeout(async () => {
                                        await show_success_popup_with_qr_barcode(
                                            frm
                                        );
                                    }, 400);
                                });
                            },
                        });
                    }
                );

                try {
                    if (is_sent_to_fbr) {
                        // Green styling for submitted invoices
                        btn.removeClass(
                            "btn-default btn-primary btn-danger btn-purple"
                        ).addClass("btn-success");
                    } else {
                        // Purple styling for pending invoices
                        btn.removeClass(
                            "btn-default btn-primary btn-danger btn-success"
                        ).addClass("btn-purple");
                    }
                } catch (e) {
                    // ignore style application errors
                }
        });
    },
});
}
register_fbr_invoice_form_handlers("Sales Invoice");
register_fbr_invoice_form_handlers("POS Invoice");

function register_fbr_invoice_item_handlers(doctype) {
frappe.ui.form.on(doctype, {
    form_render(frm, cdt, cdn) {
        render_item_scenario_detail_fields(frm, cdn);
    },

    qty(frm, cdt, cdn) {
        recalc_fbr_item_row(frm, cdt, cdn);
    },

    rate(frm, cdt, cdn) {
        recalc_fbr_item_row(frm, cdt, cdn);
    },

    custom_sales_tax_withheld_rate(frm, cdt, cdn) {
        const row = locals[cdt][cdn];
        const amount =
            parseFloat(row.amount) ||
            (parseFloat(row.qty) || 0) * (parseFloat(row.rate) || 0);
        apply_st_withheld_amount(frm, cdt, cdn, amount);
        frm.refresh_field("items");
    },

    custom_sales_tax_withheld_at_source(frm) {
        sum_st_withheld(frm);
    },

    item_tax_template(frm, cdt, cdn) {
        if (frm.__fbr_bulk_updating) return;
        recalc_fbr_item_row(frm, cdt, cdn);
    },

    custom_fbr_tax_profile(frm, cdt, cdn) {
        if (frm.__fbr_bulk_updating) return;
        copy_item_fbr_links(frm, cdt, cdn);
    },

    custom_fbr_tax_calculation_basis(frm, cdt, cdn) {
        recalc_fbr_item_row(frm, cdt, cdn);
    },

    custom_fbr_retail_price(frm, cdt, cdn) {
        recalc_fbr_item_row(frm, cdt, cdn);
    },

    custom_fbr_fixed_notified_value(frm, cdt, cdn) {
        recalc_fbr_item_row(frm, cdt, cdn);
    },

    custom_fbr_taxable_value(frm, cdt, cdn) {
        const row = locals[cdt][cdn];
        if ((row.custom_fbr_tax_calculation_basis || "") === "Manual Taxable Value") {
            recalc_fbr_item_row(frm, cdt, cdn);
        }
    },

    item_code(frm, cdt, cdn) {
        copy_item_fbr_links(frm, cdt, cdn);
        apply_fbr_item_tax_template(frm, cdt, cdn, {
            notify: false,
            forceApply: true,
        });
    },

    async custom_scenario_detail(frm, cdt, cdn) {
        await render_item_scenario_detail_fields(frm, cdn);
        if (frm.__fbr_bulk_updating) return;
        await apply_fbr_item_tax_template(frm, cdt, cdn, { notify: false });
    },

    items_add(frm, cdt, cdn) {
        if (frm.fields_dict.apply_tds) {
            frappe.model.set_value(
                cdt,
                cdn,
                "apply_tds",
                cint(frm.doc.apply_tds) ? 1 : 0
            );
        }
        if ((frm.doc.custom_scenario_detail || "").toString().trim()) {
            frappe.model.set_value(
                cdt,
                cdn,
                "custom_scenario_detail",
                frm.doc.custom_scenario_detail
            );
        }
        apply_fbr_item_tax_template(frm, cdt, cdn, { notify: false });
    },
});
}
register_fbr_invoice_item_handlers("Sales Invoice Item");
register_fbr_invoice_item_handlers("POS Invoice Item");


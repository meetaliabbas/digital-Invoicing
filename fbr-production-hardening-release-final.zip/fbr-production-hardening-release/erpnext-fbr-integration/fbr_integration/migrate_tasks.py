"""Lean after_migrate orchestration with versioned heavy syncs."""

from __future__ import annotations

import frappe

from fbr_integration.compat import ensure_desk_navigation
from fbr_integration.fbr_payload_mapping import (
	sync_payload_field_mappings,
	sync_payload_fields,
	sync_payload_source_fields,
)
from fbr_integration.item_tax_templates import sync_item_tax_templates
from fbr_integration.print_format_sync import sync_print_formats
from fbr_integration.tax_category_sync import sync_tax_categories
from fbr_integration.tax_masters import tax_masters_missing
from fbr_integration.tax_withholding_sync import sync_withholding
from fbr_integration.xpos_bridge import sync_xpos_print_formats
from fbr_integration.workspace_pos import ensure_pos_workspace_links

# Bump when fixture/sync logic changes and a full resync is required.
FBR_SYNC_VERSION = "2026.10.02"


def run_after_migrate():
	"""Always refresh desk nav; run heavy syncs only when version changes or empty."""
	from fbr_integration.pos_invoice_fields import sync_pos_invoice_fbr_fields
	from fbr_integration.taxation.fields import sync_fbr_taxation_fields
	from fbr_integration.taxation.seed import sync_fbr_taxation_masters

	ensure_desk_navigation()
	sync_print_formats()
	sync_xpos_print_formats()
	ensure_pos_workspace_links()
	sync_pos_invoice_fbr_fields()
	sync_fbr_taxation_fields()
	sync_fbr_taxation_masters()
	from fbr_integration.patches.sync_sale_types_and_item_fbr_links import (
		_ensure_item_link_fields,
		_ensure_read_permissions,
	)

	_ensure_item_link_fields()
	_ensure_read_permissions()
	ensure_desk_navigation()

	sync_tax_categories()

	current = frappe.db.get_default("fbr_integration_sync_version")
	needs_full = current != FBR_SYNC_VERSION
	needs_seed = _mapping_tables_empty()
	needs_tax = tax_masters_missing()

	if needs_full or needs_seed or needs_tax:
		sync_item_tax_templates()
		sync_withholding()
		sync_payload_fields()
		sync_payload_source_fields()
		sync_payload_field_mappings()
		# Keep retrying until a company exists and its tax masters are present.
		if not tax_masters_missing():
			frappe.db.set_default("fbr_integration_sync_version", FBR_SYNC_VERSION)
		frappe.db.commit()


def _mapping_tables_empty() -> bool:
	for dt in ("FBR Payload Field", "FBR Payload Source Field"):
		if frappe.db.exists("DocType", dt) and not frappe.db.count(dt):
			return True
	return False

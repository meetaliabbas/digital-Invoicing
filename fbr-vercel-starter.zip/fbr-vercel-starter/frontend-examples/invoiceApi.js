// Example helpers. Call these from your existing React components instead of local mock arrays.
import { supabase } from './supabaseClient';

async function authorizedFetch(url, options = {}) {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session?.access_token) throw new Error('Please sign in before using invoices.');
  const response = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${session.access_token}`,
      ...(options.headers || {})
    }
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || `Request failed (${response.status})`);
  return body;
}

export function listInvoices(tenantId) {
  return authorizedFetch(`/api/invoices?tenantId=${encodeURIComponent(tenantId)}`);
}

export function createInvoice(invoice) {
  return authorizedFetch('/api/invoices', { method: 'POST', body: JSON.stringify(invoice) });
}

export function requestFbrSubmission(invoiceId) {
  return authorizedFetch(`/api/invoices/${encodeURIComponent(invoiceId)}/submit`, { method: 'POST', body: '{}' });
}

import { z } from 'zod';
import { sendJson, methodNotAllowed } from '../../_lib/http.js';
import { userScopedSupabase, requireUser } from '../../_lib/supabase.js';

export default async function handler(req, res) {
  if (req.method !== 'POST') return methodNotAllowed(res, ['POST']);
  try {
    const supabase = userScopedSupabase(req);
    await requireUser(supabase);
    const invoiceId = req.query.id;
    if (!z.string().uuid().safeParse(invoiceId).success) return sendJson(res, 400, { error: 'Invalid invoice id' });

    const { data: invoice, error } = await supabase
      .from('invoices')
      .select('id, tenant_id, status')
      .eq('id', invoiceId)
      .single();
    if (error || !invoice) return sendJson(res, 404, { error: 'Invoice not found or access denied' });
    if (invoice.status === 'submitted' || invoice.status === 'accepted') {
      return sendJson(res, 409, { error: 'Invoice is already marked submitted; duplicate submission blocked' });
    }

    // Fail closed. FBR/PRAL request schema, auth and response semantics must be implemented
    // from the current official contract before this endpoint can transmit a real invoice.
    if (process.env.FBR_SUBMISSION_ENABLED !== 'true') {
      return sendJson(res, 503, {
        error: 'FBR submission is disabled until the official integration adapter is configured',
        code: 'FBR_ADAPTER_NOT_CONFIGURED',
        invoiceId: invoice.id,
        status: invoice.status,
        nextStep: 'Configure the current FBR/PRAL API contract and sandbox credentials; do not treat this draft as submitted.'
      });
    }

    // Deliberately do not POST a guessed payload to a government endpoint.
    // Replace this block only after validating the exact current official API specification.
    return sendJson(res, 501, {
      error: 'FBR_SUBMISSION_ENABLED is set, but the provider-specific adapter has not been implemented',
      code: 'FBR_ADAPTER_IMPLEMENTATION_REQUIRED'
    });
  } catch (error) {
    return sendJson(res, error.statusCode || 500, { error: error.message || 'Unexpected server error' });
  }
}

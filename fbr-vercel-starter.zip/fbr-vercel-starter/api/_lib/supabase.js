import { createClient } from '@supabase/supabase-js';

export function userScopedSupabase(req) {
  const url = process.env.SUPABASE_URL;
  const anonKey = process.env.SUPABASE_ANON_KEY;
  if (!url || !anonKey) {
    const error = new Error('Server Supabase configuration is missing');
    error.statusCode = 500;
    throw error;
  }

  const authHeader = req.headers.authorization || '';
  const match = authHeader.match(/^Bearer\s+(.+)$/i);
  if (!match) {
    const error = new Error('Bearer access token required');
    error.statusCode = 401;
    throw error;
  }

  // Requests run with the user's JWT so PostgreSQL Row Level Security remains in force.
  return createClient(url, anonKey, {
    auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
    global: { headers: { Authorization: `Bearer ${match[1]}` } }
  });
}

export async function requireUser(supabase) {
  const { data, error } = await supabase.auth.getUser();
  if (error || !data?.user) {
    const e = new Error('Invalid or expired access token');
    e.statusCode = 401;
    throw e;
  }
  return data.user;
}

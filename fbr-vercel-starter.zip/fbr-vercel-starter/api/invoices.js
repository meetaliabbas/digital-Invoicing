import { z } from 'zod';
import { sendJson, methodNotAllowed } from './_lib/http.js';
import { userScopedSupabase, requireUser } from './_lib/supabase.js';

const lineSchema = z.object({
  description: z.string().trim().min(1).max(300),
  quantity: z.number().positive().finite(),
  unitPrice: z.number().nonnegative().finite(),
  taxRate: z.number().min(0).max(100).default(0)
}).strict();

const createInvoiceSchema = z.object({
  tenantId: z.string().uuid(),
  invoiceNumber: z.string().trim().min(1).max(80),
  invoiceDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  buyerName: z.string().trim().min(1).max(250),
  buyerTaxId: z.string().trim().max(80).optional().nullable(),
  items: z.array(lineSchema).min(1).max(500),
  currency: z.string().length(3).default('PKR')
}).strict();

function calculate(items) {
  let subtotal = 0;
  let taxTotal = 0;
  const normalized = items.map((item) => {
    const lineSubtotal = round2(item.quantity * item.unitPrice);
    const taxAmount = round2(lineSubtotal * item.taxRate / 100);
    subtotal += lineSubtotal;
    taxTotal += taxAmount;
    return { ...item, lineSubtotal, taxAmount, lineTotal: round2(lineSubtotal + taxAmount) };
  });
  subtotal = round2(subtotal);
  taxTotal = round2(taxTotal);
  return { items: normalized, subtotal, taxTotal, total: round2(subtotal + taxTotal) };
}
function round2(n) { return Math.round((n + Number.EPSILON) * 100) / 100; }

export default async function handler(req, res) {
  if (!['GET', 'POST'].includes(req.method)) return methodNotAllowed(res, ['GET', 'POST']);
  try {
    const supabase = userScopedSupabase(req);
    await requireUser(supabase);

    if (req.method === 'GET') {
      const tenantId = typeof req.query.tenantId === 'string' ? req.query.tenantId : '';
      if (!z.string().uuid().safeParse(tenantId).success) {
        return sendJson(res, 400, { error: 'A valid tenantId query parameter is required' });
      }
      const { data, error } = await supabase
        .from('invoices')
        .select('id, tenant_id, invoice_number, invoice_date, buyer_name, buyer_tax_id, currency, items, subtotal, tax_total, total, status, fbr_reference, fbr_response, created_at, updated_at')
        .eq('tenant_id', tenantId)
        .order('created_at', { ascending: false })
        .limit(200);
      if (error) return sendJson(res, 400, { error: 'Could not load invoices', details: error.message });
      return sendJson(res, 200, { invoices: data || [] });
    }

    const parsed = createInvoiceSchema.safeParse(req.body);
    if (!parsed.success) return sendJson(res, 400, { error: 'Invalid invoice data', issues: parsed.error.issues });
    const input = parsed.data;
    const totals = calculate(input.items);
    const { data, error } = await supabase.from('invoices').insert({
      tenant_id: input.tenantId,
      invoice_number: input.invoiceNumber,
      invoice_date: input.invoiceDate,
      buyer_name: input.buyerName,
      buyer_tax_id: input.buyerTaxId || null,
      currency: input.currency.toUpperCase(),
      items: totals.items,
      subtotal: totals.subtotal,
      tax_total: totals.taxTotal,
      total: totals.total,
      status: 'draft'
    }).select('id, tenant_id, invoice_number, invoice_date, buyer_name, currency, items, subtotal, tax_total, total, status, created_at').single();

    if (error) {
      const status = /duplicate key|unique constraint/i.test(error.message) ? 409 : 400;
      return sendJson(res, status, { error: status === 409 ? 'Invoice number already exists for this tenant' : 'Could not create invoice', details: error.message });
    }
    await supabase.from('invoice_events').insert({ invoice_id: data.id, tenant_id: data.tenant_id, event_type: 'draft_created', details: { source: 'api' } });
    return sendJson(res, 201, { invoice: data });
  } catch (error) {
    return sendJson(res, error.statusCode || 500, { error: error.message || 'Unexpected server error' });
  }
}

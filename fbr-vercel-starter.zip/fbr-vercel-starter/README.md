# FBR Digital Invoicing — Vercel Gap-Bridge Starter

This package is an **overlay/starter**, not a replacement for your GitHub repository. It adds Vercel serverless API examples, Supabase/Postgres schema, request validation, authenticated API access, invoice draft persistence and a fail-closed FBR submission placeholder.

## Important limitations

- The existing repository was not cloned or run as part of generating this package. Merge files carefully; do not overwrite your existing `package.json` or app configuration blindly.
- This starter does **not** claim to submit invoices to FBR. The FBR/PRAL adapter deliberately fails closed until the current official API contract, authentication, sandbox and production onboarding are confirmed.
- Invoice fields and tax calculations here are generic scaffolding, not a certified implementation of Pakistan tax law. Have a tax professional verify applicable FBR fields, rates, codes, transaction types, invoice corrections and record retention.
- Do not deploy real taxpayer data until security, RLS, backups, access controls and sandbox tests have been reviewed.

## Contents

- `package-additions.json` — dependencies to merge into your existing package file.
- `vercel.json` — serverless function configuration.
- `.env.example` — environment variable names only; no secrets.
- `api/health.js` — API health check.
- `api/invoices.js` — authenticated list/create invoice API.
- `api/invoices/[id]/submit.js` — safe submission placeholder; no fake success.
- `api/_lib/*` — HTTP and Supabase helpers.
- `supabase/schema.sql` — tables, indexes and row-level security policies.
- `frontend-examples/*` — example Supabase client and API helpers to adapt into the existing React UI.

## Deployment steps

1. Create a Supabase project and open its SQL Editor.
2. Run `supabase/schema.sql`.
3. Create your first user through Supabase Authentication.
4. In the SQL Editor, create a row in `public.tenants`, then a matching row in `public.tenant_members` for your authenticated user's UUID and role `owner`. Use trusted admin access for this bootstrap step.
5. Merge `package-additions.json` dependencies into your current `package.json`, preserving the project's existing scripts and dependencies. Run `npm install` locally and resolve any version conflicts.
6. Copy `.env.example` values into your local `.env` and Vercel Project Settings → Environment Variables. Use the same Supabase project URL and anon/publishable key for `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `VITE_SUPABASE_URL`, and `VITE_SUPABASE_ANON_KEY` as appropriate. Never use the Supabase service-role key in the browser.
7. Copy the `api` folder and `vercel.json` into the repository root. If the existing app uses Create React App rather than Vite, adjust frontend environment variable names (`REACT_APP_*`) and adapt the example client accordingly.
8. Commit and push to your own GitHub branch, import the repository into Vercel, set the correct framework/build command, and deploy a preview first.
9. Check `https://YOUR-DEPLOYMENT.vercel.app/api/health`.
10. Test authentication and invoice creation with non-production sample data. Verify that a user who is not a tenant member cannot read or create invoices for that tenant.
11. Keep `FBR_SUBMISSION_ENABLED=false`. Complete the actual FBR/PRAL adapter against current official documentation and sandbox credentials before enabling production submissions.

## Example API

Authenticated `POST /api/invoices` JSON body:

```json
{
  "tenantId": "00000000-0000-4000-8000-000000000000",
  "invoiceNumber": "DRAFT-0001",
  "invoiceDate": "2026-10-27",
  "buyerName": "Example Buyer",
  "buyerTaxId": null,
  "currency": "PKR",
  "items": [
    { "description": "Example product", "quantity": 2, "unitPrice": 1000, "taxRate": 0 }
  ]
}
```

The zero tax rate above is only a sample input; it is not tax advice or a recommendation for real transactions.

## Current gaps still to bridge

- Review every existing repository file and merge this overlay into its real project structure.
- Add the business-specific FBR invoice payload mapper and response parser from the current official contract.
- Implement idempotency/locking for submissions and robust network timeout/reconciliation behavior before enabling transmission.
- Add validated tax rules, product/HS-code master data and any applicable buyer/seller fields.
- Add user/tenant bootstrap UI and role-management workflow; currently tenant membership setup is manual.
- Add automated tests, audit logging coverage, rate limits and production security review.

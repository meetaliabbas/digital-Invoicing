-- Apply in Supabase SQL Editor. Review against your actual business/tax requirements before production.
create extension if not exists pgcrypto;

create table if not exists public.tenants (
  id uuid primary key default gen_random_uuid(),
  legal_name text not null,
  ntn text,
  sales_tax_registration_number text,
  address text,
  created_at timestamptz not null default now()
);

create table if not exists public.tenant_members (
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'owner' check (role in ('owner','admin','accountant','viewer')),
  created_at timestamptz not null default now(),
  primary key (tenant_id, user_id)
);

create table if not exists public.invoices (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  invoice_number text not null,
  invoice_date date not null,
  buyer_name text not null,
  buyer_tax_id text,
  currency char(3) not null default 'PKR',
  items jsonb not null,
  subtotal numeric(18,2) not null check (subtotal >= 0),
  tax_total numeric(18,2) not null check (tax_total >= 0),
  total numeric(18,2) not null check (total >= 0),
  status text not null default 'draft' check (status in ('draft','queued','submitted','accepted','rejected','cancelled')),
  fbr_reference text,
  fbr_response jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (tenant_id, invoice_number)
);

create table if not exists public.invoice_events (
  id uuid primary key default gen_random_uuid(),
  invoice_id uuid not null references public.invoices(id) on delete cascade,
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  event_type text not null,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists invoices_tenant_created_idx on public.invoices (tenant_id, created_at desc);
create index if not exists invoice_events_invoice_created_idx on public.invoice_events (invoice_id, created_at desc);

create or replace function public.is_tenant_member(check_tenant uuid)
returns boolean language sql stable security definer set search_path = public
as $$ select exists (
  select 1 from public.tenant_members tm
  where tm.tenant_id = check_tenant and tm.user_id = auth.uid()
); $$;

alter table public.tenants enable row level security;
alter table public.tenant_members enable row level security;
alter table public.invoices enable row level security;
alter table public.invoice_events enable row level security;

drop policy if exists "members can read their tenants" on public.tenants;
create policy "members can read their tenants" on public.tenants for select using (public.is_tenant_member(id));

drop policy if exists "users can read own memberships" on public.tenant_members;
create policy "users can read own memberships" on public.tenant_members for select using (user_id = auth.uid());

drop policy if exists "members can read invoices" on public.invoices;
create policy "members can read invoices" on public.invoices for select using (public.is_tenant_member(tenant_id));
drop policy if exists "members can create invoices" on public.invoices;
create policy "members can create invoices" on public.invoices for insert with check (public.is_tenant_member(tenant_id));
drop policy if exists "members can update invoices" on public.invoices;
create policy "members can update invoices" on public.invoices for update using (public.is_tenant_member(tenant_id)) with check (public.is_tenant_member(tenant_id));

drop policy if exists "members can read invoice events" on public.invoice_events;
create policy "members can read invoice events" on public.invoice_events for select using (public.is_tenant_member(tenant_id));
drop policy if exists "members can add invoice events" on public.invoice_events;
create policy "members can add invoice events" on public.invoice_events for insert with check (public.is_tenant_member(tenant_id));

-- Bootstrap steps after creating your first Supabase Auth user:
-- 1) Insert your tenant into public.tenants and copy its id.
-- 2) Insert (tenant_id, user_id, role='owner') into public.tenant_members using your Auth user's UUID.
-- Do not expose service-role keys in frontend code. Use the SQL editor only for trusted setup.
